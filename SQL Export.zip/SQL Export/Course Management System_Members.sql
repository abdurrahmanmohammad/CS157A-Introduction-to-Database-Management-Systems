-- MySQL dump 10.13  Distrib 8.0.20, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: Course Management System
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Members`
--

DROP TABLE IF EXISTS `Members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Members` (
  `ID` char(9) NOT NULL,
  `firstname` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Members`
--

LOCK TABLES `Members` WRITE;
/*!40000 ALTER TABLE `Members` DISABLE KEYS */;
INSERT INTO `Members` VALUES ('100859622','Mia','Hodge','(310)704-6500','miahodge@cms.com','Worcester, MA 01604'),('189826755','July','Anne','(202)500-7430','julyanne@cms.com','4 Sugar Street'),('199526438','Pasquale','Nelson','(745) 243-1323','pasqualenelson@cms.com','Battle Creek, MI 49015'),('204722757','Alice','Sims','(589) 871-3681','alicesims@cms.com','San Jose, CA 95127'),('226084272','Erin','Weber','(346) 266-2473','erinweber@cms.com','8267 Rock Maple Drive'),('227209241','Raymon','Bailey','(750) 488-7011','raymonbailey@cms.com','229 SW. Ocean Ave.'),('237393883','Angelique','Davila','(270)493-4957','angeliquedavila@cms.com','40 Jockey Hollow Dr.'),('290327837','Nichole','Frost','(891) 297-0455','nicholefrost@cms.com','Clearwater, FL 33756'),('292211500','Antoinette','Marks','(939) 935-8994','antoinettemarks@cms.com','75 Longbranch Dr.'),('305981136','Polly','Rios','(809) 914-2643','pollyrios@cms.com','Peabody, MA 01960'),('307562770','Alton','Gallagher','(359) 351-7168','altongallagher@cms.com','90 Eagle Street'),('314843835','Myrtle','Haney','(953) 493-3646','myrtlehaney@cms.com','Auburndale, FL 33823'),('318547937','Tom','Adrian','(207)400-8304','tomadrian@cms.com','Port Orange, FL 32127'),('320798136','Bob','Bryant','(828)276-7614','bobbryant@cms.com','Lewiston, ME 04240'),('337767185','Cherie','French','(241) 768-9215','cheriefrench@cms.com','9117 Arnold Street'),('339820994','Reyna','Colon','(383) 592-3560','reynacolon@cms.com','Saint Cloud, MN 56301'),('378503098','Jack','Vargas','(908) 442-4062','jackvargas@cms.com','Pasadena, MD 21122'),('409326430','Shelia','Elliott','(386)438-4907','sheliaelliott@cms.com','45 Circle Avenue'),('418130858','Inez','Tate','(302)422-6181','ineztate@cms.com','556 Trusel Ave.'),('435313478','Wilber','Melton','(802)398-4468','wilbermelton@cms.com','Niceville, FL 32578'),('452018548','Bud','Kirby','(919) 601-5112','budkirby@cms.com','85 Selby Street'),('483131196','Beatriz','Downs','(780) 422-7078','beatrizdowns@cms.com','Aiken, SC 29803'),('503432266','Carol','Lynn','(446) 747-1918','carollynn@cms.com','78 Summer St.'),('506190495','Verna','Copeland','(395) 913-5631','vernacopeland@cms.com','7 East Trusel Drive'),('538782975','Dustin','Warren','(501) 342-1537','dustinwarren@cms.com','Simpsonville, SC 29680'),('546664173','Antoine','Deleon','(224)441-8546','antoinedeleon@cms.com','7731 S. Wagon Street'),('549281974','Agustin','Barrett','(852) 761-0810','agustinbarrett@cms.com','Bartlett, IL 60103'),('573062892','Thanh','Everett','(339) 936-4988','thanheverett@cms.com','8227 William St.'),('57906941','Steven','Suarez','(254) 567-1538','stevensuarez@cms.com','49 Lees Creek Ave.'),('587779626','Deangelo','Franklin','(650)559-4049','deangelofranklin@cms.com','Bradenton, FL 34203'),('600242738','Ward','Benitez','(848)219-2884','wardbenitez@cms.com','Windermere, FL 34786'),('603160432','Normand','Sheppard','(346)932-8180','normandsheppard@cms.com','94 Glen Ridge Drive'),('611668180','Edison','Carter','(614)653-6066','edisoncarter@cms.com','Paterson, NJ 07501'),('620381807','Jackson','Blankenship','(305)742-8761','jacksonblankenship@cms.com','Bakersfield, CA 93306'),('622426523','Colette','Stark','(832)665-2899','colettestark@cms.com','95 Gulf Drive'),('638993187','Cary','Lank  ','(567)200-5875','carylank  @cms.com','Warren, MI 48089'),('661054866','Wes','Gill','(479)820-5552','wesgill@cms.com','9089 Edgewater Court'),('670202202','Mose','Mcdonald','(627) 579-8894','mosemcdonald@cms.com','254 Littleton Drive'),('670334459','Brendon','Frazier','(205)879-2848','brendonfrazier@cms.com','8527 Madison Lane'),('689582238','Dana','Conway','(583) 630-1598','danaconway@cms.com','Shirley, NY 11967'),('716801899','Roscoe','Richard','(303) 819-2145','roscoerichard@cms.com','Bardstown, KY 40004'),('722640650','Jeff','Hanson','(339)224-3622','jeffhanson@cms.com','892 Walt Whitman Dr.'),('760511911','Luciano','Smith','(592) 205-4019','lucianosmith@cms.com','251 San Carlos Ave.'),('764777061','Miguel','Mathews','(841) 394-2348','miguelmathews@cms.com','63 Purple Finch Drive'),('796058602','Miles','Larson','(898) 723-7801','mileslarson@cms.com','South Portland, ME 04106'),('798100317','Honey','Dent  ','(305)448-4944','honeydent  @cms.com','72 N. Pumpkin Hill St.'),('851438868','Clara','Bradford','(304)507-6675','clarabradford@cms.com','Sioux Falls, SD 57103'),('861394637','Sam','Heister','(276)447-3045','samheister@cms.com','258 Kent Drive'),('875783848','Allen','Zuniga','(671)635-4007','allenzuniga@cms.com','Vernon Hills, IL 60061'),('877078818','Hank','Colley','(530)655-4881','hankcolley@cms.com','444 Hartford Street'),('889872253','Bertram','Carlson','(614)341-4812','bertramcarlson@cms.com','Lake Zurich, IL 60047'),('891149217','Catalina','Schaefer','(575)208-7495','catalinaschaefer@cms.com','Lilburn, GA 30047'),('916994127','Quinn','Warner','(385) 289-9498','quinnwarner@cms.com','12 N. Oak Circle'),('932823238','Jonas','Padilla','(605) 452-4957','jonaspadilla@cms.com','Klamath Falls, OR 97603'),('943667551','Justine','Mcbride','(607)898-3165','justinemcbride@cms.com','Derby, KS 67037'),('944806400','Artie','Smoak','(229)496-5839','artiesmoak@cms.com','Victoria, TX 77904'),('951597733','Lupe','Juarez','(816) 842-3578','lupejuarez@cms.com','647 Vale Street'),('957713740','Sylvia','Fuentes','(331)254-9063','sylviafuentes@cms.com','7890 Cross Road'),('978594399','Gina','Hernandez','(454) 582-4008','ginahernandez@cms.com','6 High Point St.'),('996595763','Tamara','Gibson','(289)276-8056','tamaragibson@cms.com','182 Sherman Ave.');
/*!40000 ALTER TABLE `Members` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04 19:26:44
