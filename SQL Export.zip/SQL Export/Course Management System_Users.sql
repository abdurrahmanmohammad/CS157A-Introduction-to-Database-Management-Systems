-- MySQL dump 10.13  Distrib 8.0.20, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: Course Management System
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Users` (
  `ID` char(9) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES ('100859622','miahodge','d5VjTxRv'),('189826755','julyanne','QuWEn3JY'),('199526438','pasqualenelson','dtmXMeXQ'),('204722757','alicesims','PRccSb8w'),('226084272','erinweber','me86RtTE'),('227209241','raymonbailey','VsYJATqZ'),('237393883','angeliquedavila','EVeecmD8'),('290327837','nicholefrost','MfcsWbK2'),('292211500','antoinettemarks','CHWpcLRy'),('305981136','pollyrios','aNmfmjZz'),('307562770','altongallagher','4jBjBy2V'),('314843835','myrtlehaney','MNM2AtPk'),('318547937','tomadrian','WKSmMKQs'),('320798136','bobbryant','YP9buH86'),('337767185','cheriefrench','VfLaPDNc'),('339820994','reynacolon','7V6MXU3a'),('378503098','jackvargas','75dE3A9S'),('409326430','sheliaelliott','yMSRdrA5'),('418130858','ineztate','q7DxJ3SQ'),('435313478','wilbermelton','KkLgXbZy'),('452018548','budkirby','nKGR6CR5'),('483131196','beatrizdowns','Sv9HCyJ3'),('503432266','carollynn','2M6u6rYH'),('506190495','vernacopeland','Y2Ue3gBp'),('538782975','dustinwarren','V6ubrbxJ'),('546664173','antoinedeleon','9BB99DAD'),('549281974','agustinbarrett','BeLrn6q5'),('573062892','thanheverett','Uusw4YzL'),('57906941','stevensuarez','P4mvNLsM'),('587779626','deangelofranklin','vA2u75f3'),('600242738','wardbenitez','E3zuH3XC'),('603160432','normandsheppard','yQVv2gMB'),('611668180','edisoncarter','mX4j828U'),('620381807','jacksonblankenship','9YkgdG2W'),('622426523','colettestark','fBV6cZbR'),('638993187','carylank  ','7T4gK8rD'),('661054866','wesgill','AJCvTtW3'),('670202202','mosemcdonald','NaCkSyed'),('670334459','brendonfrazier','yNQCzf32'),('689582238','danaconway','SG7rYYvr'),('716801899','roscoerichard','jqtkKEqv'),('722640650','jeffhanson','35nv3LG3'),('760511911','lucianosmith','DZvh6tbG'),('764777061','miguelmathews','EebfEAPh'),('796058602','mileslarson','5X4MubZq'),('798100317','honeydent  ','HunPcxcs'),('851438868','clarabradford','PQMkvujJ'),('861394637','samheister','cvJuMuLk'),('875783848','allenzuniga','YCmHmynj'),('877078818','hankcolley','uFg2BP3n'),('889872253','bertramcarlson','9XUBTyct'),('891149217','catalinaschaefer','XYnPd2yF'),('916994127','quinnwarner','eqbUqL4c'),('932823238','jonaspadilla','vYWxnrY9'),('943667551','justinemcbride','7xfP2bZJ'),('944806400','artiesmoak','RAw3dPpX'),('951597733','lupejuarez','sczEfLZF'),('957713740','sylviafuentes','P4FnnKvG'),('978594399','ginahernandez','MWwxgHrK'),('996595763','tamaragibson','K4QpExve');
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-04 19:26:44
